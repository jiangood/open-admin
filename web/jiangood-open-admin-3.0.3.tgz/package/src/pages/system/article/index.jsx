import {PlusOutlined} from '@ant-design/icons'
import {Button, Form, Input, InputNumber, Popconfirm} from 'antd'
import React from 'react'
import {
    DictUtils,
    FieldBoolean,
    FieldDictSelect,
    FieldEditor,
    FormModal,
    HttpUtils,
    Page,
    PermActions,
    ProTable
} from "../../../framework";

const {TextArea} = Input;

export default class extends React.Component {

    state = {
        editing: false,
    }

    modalRef = React.createRef()
    tableRef = React.createRef()

    handleAdd = () => {
        this.setState({editing: false})
        this.modalRef.current.open({})
    }

    handleEdit = record => {
        this.setState({editing: true})
        this.modalRef.current.open(record)
    }

    onFinish = async values => {
        const isNew = !values.id;
        const url = isNew ? 'admin/article/create' : 'admin/article/update';
        await HttpUtils.post(url, values)
        this.tableRef.current.reload()
    }

    handleDelete = record => {
        HttpUtils.post('admin/article/delete', {id: record.id}).then(rs => {
            this.tableRef.current.reload()
        })
    }

    columns = [
        {
            title: '编码',
            dataIndex: 'code',
        },
        {
            title: '标题',
            dataIndex: 'title',
        },
        {
            title: '显示位置',
            dataIndex: 'position',
            render(v) {
                return DictUtils.dictLabel('articlePosition', v) || v
            },
        },
        {
            title: '排序',
            dataIndex: 'seq',
        },
        {
            title: '启用',
            dataIndex: 'enabled',
            render(v) {
                return v == null ? null : (v ? '是' : '否')
            },
        },
        {
            title: '操作',
            dataIndex: 'option',
            render: (_, record) => {
                return (
                    <PermActions>
                        <Button size='small' perm='article:update' onClick={() => this.handleEdit(record)}>编辑</Button>
                        <Popconfirm perm='article:delete' title='确定删除?' onConfirm={() => this.handleDelete(record)}>
                            <Button size='small'>删除</Button>
                        </Popconfirm>
                    </PermActions>
                );
            },
        },
    ]

    render() {
        return <Page
            title="文章管理"
            description="管理系统文章，如关于、帮助等页面"
        >
            <ProTable
                actionRef={this.tableRef}
                toolBarRender={() => (
                    <PermActions>
                        <Button perm='article:create' type='primary' icon={<PlusOutlined/>} onClick={this.handleAdd}>新增</Button>
                    </PermActions>
                )}
                request={(params) => HttpUtils.get('admin/article/page', params)}
                columns={this.columns}
                searchFormRender={() => (
                    <>
                        <Form.Item label='编码' name='code'>
                            <Input/>
                        </Form.Item>
                        <Form.Item label='标题' name='title'>
                            <Input/>
                        </Form.Item>
                    </>
                )}
            />

            <FormModal ref={this.modalRef} title='文章' width={800} onFinish={this.onFinish}>

                <Form.Item label='编码' name='code' rules={[{required: true}]}>
                    <Input disabled={this.state.editing}/>
                </Form.Item>

                <Form.Item label='标题' name='title' rules={[{required: true}]}>
                    <Input/>
                </Form.Item>

                <Form.Item label='内容' name='content'>
                    <FieldEditor />
                </Form.Item>

                <Form.Item label='显示位置' name='position' rules={[{required: true}]}>
                    <FieldDictSelect typeCode='articlePosition'/>
                </Form.Item>

                <Form.Item label='排序' name='seq'>
                    <InputNumber/>
                </Form.Item>

                <Form.Item label='启用' name='enabled'>
                    <FieldBoolean/>
                </Form.Item>
            </FormModal>
        </Page>
    }
}
